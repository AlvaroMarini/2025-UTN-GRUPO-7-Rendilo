import React from "react";
import { createRoot } from "react-dom/client";
import { createBrowserRouter, RouterProvider } from "react-router-dom";
import App from "./App.jsx";
import profesores from "./pages/profesores.jsx";
import alumnos from "./pages/alumnos.jsx";
import editExam from "./pages/editExam.jsx";
import takeExam from "./pages/takeExam.jsx";
import "./index.css";

const router = createBrowserRouter([
  {
    path: "/",
    element: <App />, // Header + Footer + <Outlet/>
    children: [
      { index: true, element: <ProfesPage /> },
      { path: "profes", element: <ProfesPage /> },
      { path: "alumnos", element: <AlumnosPage /> },
      { path: "examen/:id/editar", element: <EditExam /> },
      { path: "examen/:id/rendir", element: <TakeExam /> },
    ],
  },
]);

createRoot(document.getElementById("root")).render(<RouterProvider router={router} />);
