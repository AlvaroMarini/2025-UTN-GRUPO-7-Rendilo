// Cambiá esta línea cuando migres a Prisma:
// import { examRepo } from "./PrismaExamRepo";
import { PrismaExamRepo } from "./PrismaExamRepo.ts";
export const examRepo = new PrismaExamRepo();

